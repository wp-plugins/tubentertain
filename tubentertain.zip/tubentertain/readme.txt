=== TubEntertain ===
Contributors: Justin, Tolu
Tags: YouTube, TubEntertain, Player, Wordpress , Player, Video On Demand,  
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=385UR7MYGGB24
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 4.1
Version: 1.0
Author: Adegoroye Owolabi
Author URI: http://tubentertain.com/
License: GNU General Public License v2 or later
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
== Description ==
TubEntertain Is a Powerful Plugin That Let You Create a Video Gallery of Your YouTube Live Stream and All Uploaded Videos In Your WordPress  or  Other Website, Alongside With Your Twitter Live Stream, It Is Very Simple, Yet Dynamic.
TubEntertain Is A Full Responsive Video Player Plugin for wordpress. 
Version 1.0 is  Youtube Api V2 and Twitter Api V1.1  Compliance, while the pro copy is Youtube Api V3  and Twitter Api V1.1  Compliance
For further customization please contact entertainer@tubentertain.com
Link to [TubEntertain]( http://tubentertain.com/t)

== Installation ==
1. Upload or Download "TubEntertain" to the "/wp-content/plugins/" directory.
2. Activate the plugin through the "Plugins" menu in WordPress.
3. Go to the plugin setting type in your youtube username,
 (if you don't have youtube user name, then you need to login to your youtube account, 
 follow the advance option in your user page, 
 you should see option which says create new url or custom url,
 once you are able to create url you have automatically generate youtube user name,
 you will have a similar url [https://www.youtube.com/user/your_new_usename]
 all you need there is the username not the full url,
 copy the user name and enter it into the "YouTube UserName" Input on TubEntertain admin section)

3B if you using the Pro copy you will your channel ID instead of user name.
   
4. Finally, copy and paste "[tubentertain]" in your templates or page you will like your player to appear.
== Frequently Asked Questions ==
A question that someone might have, should be email to adego247@gmail.com, best you can follow the blog on http://tubentertain.com/.

== Screenshots ==
1. This how the playlist look like screenshot-1.png .
2. This how the player screen look like screenshot-2.png .

==Features==

1.Populate all your own uploaded YouTube video galleries on your site or within your mobile application.
Youtube Api V3 and Twitter Api V1.1 Compliance.

2.Scroll to view on video played
3.Subscription button enable
4.Viewers Statistics (coming soon)
5.Populate your YouTube Live Stream on your site.
6.Enable video download (coming soon)
7.Populate your Twitter Real Time Updates on your site.
8.Brand your own uploaded YouTube video, like they saved on your site.
9.Responsive interface tested prove.
10.Work smoothly on IE 8+, Firefox, Chrome, and Safari.
11.Effortlessly used in WordPress templates.
12.Tested and compatible up to WordPress Version 4+.
13.Switch between Live View or Feature Video and Playlist.
14.After clicking a thumbnail, videos can play.
15.Videos play perfectly on nearly every mobile device that supports HTML5 or Flash.
16.Automatically start the next video in a playlist gallery when playback ended.
17.One full year of priority support.
18.No monthly or long term subscription.
19.First customization support request is free, further request may deserve charges.

== Changelog ==
= 0.2 =
* Add more option to plugin setting.
* few Css amendmens.

= 0.1 =
* Initial release.

== Upgrade Notice ==
= 0.2 =
With upgraded copy you can do more such as  create video categories, e.g Misic | Movies | Comedy
and create playlist accordingly. 

= 0.1 =
Initial release.

